<?php
		include_once ('header.php'); 
?>

<!--====== SLIDER PART START ======-->
   
    <section id="slider-part" class="slider-active">
        <div class="single-slider bg_cover pt-150" style="background-image: url(images/slider/s-1.jpg)" data-overlay="4">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont">
                            <h1 data-animation="bounceInLeft" data-delay="1s"></h1>
                            <p data-animation="fadeInUp" data-delay="1.3s"></p>
                            <!--
							<ul>
                                <li><a data-animation="fadeInUp" data-delay="1.6s" class="main-btn" href="#">Read More</a></li>
                                <li><a data-animation="fadeInUp" data-delay="1.9s" class="main-btn main-btn-2" href="#">Get Started</a></li>
                            </ul>
							-->
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- single slider -->
        
        <div class="single-slider bg_cover pt-150" style="background-image: url(images/slider/s-2.jpg)" data-overlay="4">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont">
                            <h1 data-animation="bounceInLeft" data-delay="1s"></h1>
                            <p data-animation="fadeInUp" data-delay="1.3s"></p>
                            <!--
							<ul>
                                <li><a data-animation="fadeInUp" data-delay="1.6s" class="main-btn" href="#">Read More</a></li>
                                <li><a data-animation="fadeInUp" data-delay="1.9s" class="main-btn main-btn-2" href="#">Get Started</a></li>
                            </ul>
							-->
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- single slider -->
        
        <div class="single-slider bg_cover pt-150" style="background-image: url(images/slider/s-3.jpg)" data-overlay="4">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont">
                            <h1 data-animation="bounceInLeft" data-delay="1s"></h1>
                            <p data-animation="fadeInUp" data-delay="1.3s"></p>
                            <!--
							<ul>
                                <li><a data-animation="fadeInUp" data-delay="1.6s" class="main-btn" href="#">Read More</a></li>
                                <li><a data-animation="fadeInUp" data-delay="1.9s" class="main-btn main-btn-2" href="#">Get Started</a></li>
                            </ul>
							-->
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- single slider -->
    </section>
    
    <!--====== SLIDER PART ENDS ======-->
   
    <!--====== CATEGORY PART START ======-->
    
    
    <!--====== CATEGORY PART ENDS ======-->
   
    <!--====== ABOUT PART START ======-->
    
    <section id="about-part" class="pt-65">
         <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="section-title mt-50">
                        
                        <h2>Welcome to Maheshwari Public school </h2>
						<h5>(Unit of Shree Mahesh Shaikshanik, Avam Seva Pranyas,Bikaner)</h5>
                    </div> <!-- section title -->
                    <div class="about-cont">
                         <p><b>MPS</b> is going to mark a foot print on the path of progressive and quality education. We hereby, provide all the facilities to the students so that they can reach heights not only in academics but also in exploration of the life around.</p>
						As totally groomed with modern technology and dedicated teachers we assure holistic development of a child.<br>
						<p><b>“Change is the basic law of nature but the changes brought by the passage of time effects individual and institutions in different ways”.</b></p>
						We have a great hope with our this new venture which would surely take us to the new <strong>summit</strong> of education.
						
                        
                    </div>
                </div> <!-- about cont -->
                <div class="col-lg-6 offset-lg-1">
                    <div class="about-event mt-50">
                       
                        <img src="images/about/bg-1.png" alt="About">
                    </div> <!-- about event -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
		<div class="back">
						
					</div>
        
    </section>
    
    <!--====== ABOUT PART ENDS ======-->
   
    <!--====== APPLY PART START ======-->
    <!--
    <section id="apply-aprt" class="">
        <div class="container">
            <div class="apply">
                <div class="row no-gutters" width="100">
                    <div class="col-lg-6">
                        <div class="apply-cont apply-color-1">
                           
                            <h3>Our school is equipped with:</h3>
							
							<ul class="numbering">
							<li> Magnificent Infrastructure</li>
							<li>Competent and Friendly Staff</li>
							<li>Delightful Atmosphere</li>
							<li> all Modern Amenities</li>
							<li>Air Conditioned Classrooms</li>
							<li>Smart Classes & Digital Classrooms</li>
							<li>High Security with CCTV Surveillance</li>
							<li>Emphasis on Moral Values</li>
							<li>Enriched Library</li>
							<li>Music,Dance</li>
							<li>Art & Craft</li>
							
							</ul>
							
                            <!-- <a href="#" class="main-btn">Apply Now</a> -->
                      <!--  </div> <!-- apply cont -->
                   <!-- </div>
					
                    
					<div class="col-lg-6">
                        <div class="apply-cont apply-color-2">
                             <div class="about-event">
								<div class="event-title">
								<h3>Upcoming events</h3>
								</div> <!-- event title -->
							<!--	<ul>
                            <li>
                                <div class="singel-event">
									<span><h1>Inauguration</h1><span>
                                    <span><i class="fa fa-calendar"></i> 10th April 2022</span>
                                    
                                    <span><i class="fa fa-clock-o"></i> 5:30pm</span>
                                    <span><a href="https://goo.gl/maps/N4YE1ysLQ5mSEKhv8" target="_blank"><i class="fa fa-map-marker"></i>School Campus</a></span>
                                </div>
                            </li>
                            <!--
							<li>
                                <div class="singel-event">
                                    <span><i class="fa fa-calendar"></i> 2 December 2018</span>
                                    <a href="events-singel.html"><h4>Tech Summit</h4></a>
                                    <span><i class="fa fa-clock-o"></i> 10:00 Am - 3:00 Pm</span>
                                    <span><i class="fa fa-map-marker"></i> Rc Auditorim</span>
                                </div>
                            </li>
                            <li>
                                <div class="singel-event">
                                    <span><i class="fa fa-calendar"></i> 2 December 2018</span>
                                    <a href="events-singel.html"><h4>Enviroement conference</h4></a>
                                    <span><i class="fa fa-clock-o"></i> 10:00 Am - 3:00 Pm</span>
                                    <span><i class="fa fa-map-marker"></i> Rc Auditorim</span>
                                </div>
                            </li>
							-->
                     <!--   </ul> 
                    </div> <!-- about event -->
                 <!--   </div> 
                    </div> 
					
                </div>
				
            </div> <!-- row -->
     <!--   </div> <!-- container -->
  <!--  </section>
	
	<!-- message part start-->
	 <section id="event-page" class="pt-10 pb-20 gray-bg">
        <div class="container">
           <div class="row">
               
               
               <div class="col-lg-6">
                   <div class="singel-event-list mt-30">
                       <div class="event-thum">
                           <img src="images/trustee/t-1.jpg" alt="Message" height="170" width="120">
						   <div>
                                        <a href="presidentmsg.html"><h6>Shriram Singhi</h6></a><br>
                                        <span><b>President</b></span>
                            </div>
                       </div>
					   
                       <div class="event-cont">
                           <span><p>"Somewhere ,something incredible is waiting to be known,."-<b> Carl sagan </b></p></span>
                            
							<div class="button">
                               <a href="presidentmsg.html" class="readmore-btn">Read more</a>
							</div>
                       </div>
						
                   </div>
               </div>
               <div class="col-lg-6">
                   <div class="singel-event-list mt-30">
                       <div class="event-thum" text-align="center">
                           <img src="images/trustee/t-2.jpg" alt="Message" height="170" width="120">
						   <div class="cont">
                                        <a href="principalmsg.html"><h6>Rajesh Tiwari</h6></a><br>
                                        <span><b>Principal</b></span>
                            </div>
                       </div>
					   
                       <div class="event-cont">
                           
                           <span> <p>Education is a shared commitment between dedicated teachers, motivated students and enthusiastic parents with high expectations.</p></span>
							<div class="button">
                                <a href="principalmsg.html" class="readmore-btn">Read more</a>
							</div>
                       </div>
						
                   </div>
               </div>
			   <div class="col-lg-6">
                   <div class="singel-event-list mt-30">
                       <div class="event-thum" text-align="center">
                           <img src="images/trustee/t-3.jpg" alt="Message" height="170" width="120">
						   <div>
                                        <a href="secretary.html"><h6>Tolaram pariwal</h6></a><br>
                                        <span><b>secretary</b></span>
                            </div>
                       </div>
					   
                       <div class="event-cont">
                           <span><p>"“A Journey of a thousand miles begins with a single step” 
									<b>– Lao Tzu</b></p>
							</span>
                            
							<div class="button">
                                <a href="secretary.html" class="readmore-btn">Read more</a>
							</div>
                       </div>
						
                   </div>
               </div>
           </div> <!-- row -->
           
        </div> <!-- container -->
    </section>
<?php include("footer.php");
?>