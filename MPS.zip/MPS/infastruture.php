<?php

	include('header.php');
?>
	 <!--====== PAGE BANNER PART START ======-->
    
    <section id="page-banner" class="pt-105 pb-110" data-overlay="8" style="background-color:#2F4F4F">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2>Our school with</h2>
                        
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
   
	
	
	   <section id="about-page" class="pt-20 pb-50">
        <div class="container">
            <div class="row">
                <div class="">
                    <div class="section-title mt-50 pb-20">
							<h1>Ours school with:</h1>
						</div> <!-- section title -->
                       
                       <div class="about-cont">
							
                           <ul>
						   
						   <li>Spacious Air-Conditioned classrooms with interactive audio-visual technology.</li>
							<li>Transport facilities enabled with GPS tracking.</li>
							<li>Fully equipped with modern ICT(Information and Communication Technology).</li>
							<li>Well-equipped laboratories for Physics, Chemistry and Biology.</li>
							<li>Best Sports facilities in various disciplines with well experienced coaches.</li>
							<li>Fully-fledged and digitally equipped library.</li>
							<li>Extra-Curricular activities for grooming personality and holistic learning experience.</li>
							<li>High security with CCTV Surveillance and unified technology.</li>
							<li>Well equipped and hygienic Medicare Room.</li>
							<li>Green Lawns.</li>
							<li>Play station for kids.</li>
							<li>Exclusive activity for pre-primary.</li>
							<li>R.O purification plant for drinking water.</li>
							<li>Indoor games room.</li>

						   </ul>
                           
                            
					    </div>
                   
                   
                        
               </div>
                         </div> <!-- row -->
        </div> <!-- container -->
    </section>
	
	
<?php

	include('footer.php');
?>