<?php include('header.php');
?>

	 <!--====== PAGE BANNER PART START ======-->
    
    <section id="page-banner" class="pt-105 pb-110" data-overlay="8" style="background-color:#2F4F4F">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2>From The Desk Of President </h2>
                        
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
   
	
	
	  <section id="blog-page" class="pt-90 pb-120 gray-bg">
        <div class="container">
           <div class="row">
               <div class="col-lg-8">
                   <div class="singel-blog mt-30">
                       <div class="blog-thum">
                          
                       </div>
                       <div class="blog-cont">
                           
                           
                        <p align="justify"><b>“Somewhere, something incredible is waiting to be known.”-Carl Sagan</b><br><br>
						<p align="justify">It gives me immense pleasure to communicate with the society on behalf of <b>SMSSP, Bikaner</b>. We are glad to inform you that we have started Maheshwari Public School with a vision of providing quality education coupled with all modern amenities and advanced technology. We further aim to make this CBSE affiliated curriculum. The magnificent infrastructure will create an ideal atmosphere for better learning. Besides academic excellence, our aim is to discover the hidden potential and skill of every child by providing them ample opportunities of development.</p><br>
						<p align="justify">We at <b>MPS</b> will try to instill into the young minds the creative approach to problems, confidence in their actions, concern for fellow human beings. We seek to develop and nurture the different facets of a child. From academic to dance, music and a variety of sports, we focus on enhancing the mental and physical abilities of a student. We also endeavour to provide the students Value Based Education to handle real life problems and create opportunities for themselves and society as well.</p>
						<p align="right"><b>Shriram singhi<br> President</b></p>
				
					
						
                        
                       </div>
                   </div> <!-- singel blog -->
                   
                        
               </div>
               <div class="col-lg-4">
                   <div class="saidbar">
                       <div class="row">
                           <div class="col-lg-12 col-md-6">
                               <div class="">
                                    <img src="images/trustee/t-1.jpg" alt="About" width="350" height="500">
									<div class="cont">
										<h4>Shriram Singhi</h4>
										<h6>President</h6>
									</div>
                               </div> <!-- saidbar search -->
                               
                           </div> <!-- categories -->
                           
                           
                       </div> <!-- row -->
                   </div> <!-- saidbar -->
               </div>
           </div> <!-- row -->
        </div> <!-- container -->
    </section>
	
	
	<?php include('footer.php');
	?>