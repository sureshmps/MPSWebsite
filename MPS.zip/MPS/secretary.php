<?php include('header.php');
?>
	 <!--====== PAGE BANNER PART START ======-->
    
    <section id="page-banner" class="pt-105 pb-110" data-overlay="8" style="background-color:#2F4F4F">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2>From The Desk Of Secretary </h2>
                        
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
   
	
	
	  <section id="blog-page" class="pt-90 pb-120 gray-bg">
        <div class="container">
           <div class="row">
               <div class="col-lg-8">
                   <div class="singel-blog mt-30">
                       <div class="blog-thum">
                          
                       </div>
                       <div class="blog-cont">
							<P align="justify"><B>“A journey of a thousand miles begins with a single step.”<p>
							<p align="right">		<BR>-lao tzu</B></p>

                           
                            <p align="justify">In an era of firm competition, success can only be achieved by the right kind of effort at right time.</p><br>
							<p align="justify">Marching ahead with staunch principles to dispel illusions, ignorance and promoting acquisition of knowledge among masses, we are unfurling the flag of Maheshwari Public School with dignity and pride your effort in choosing MPS, Bikaner should be your best choice and I am pleased to welcome you on behalf of MPS which is a unit of SMSASP, Bikaner.</p><br>
							<p align="justify">We will be following the ideals of learning by giving opportunities to students to develop their personality through different co-curricular, extra-curricular activities and personality enhancement skills.MPS believes in imparting quality education based on ethics.</p><br>
							<p align="justify">I look forward to welcoming you to join and contribute to our journey towards exploring new horizons in the field of education with wisdom.<p><br>
							<p align="right"><b>Tolaram Pariwal<br> Secretary</b></p>

					    </div>
                   </div> <!-- singel blog -->
                   
                        
               </div>
               <div class="col-lg-4">
                   <div class="saidbar">
                       <div class="row">
                           <div class="col-lg-12 col-md-6">
                               <div class="">
                                    <img src="images/trustee/t-3.jpg" alt="About" width="350" height="500">
									<div class="cont">
										<h4>Tolaram pariwal</h4>
										<h6>Secretary</h6>
									</div>
                               </div> <!-- saidbar search -->
                               
                           </div> <!-- categories -->
                           
                           
                       </div> <!-- row -->
                   </div> <!-- saidbar -->
               </div>
           </div> <!-- row -->
        </div> <!-- container -->
    </section>
	
<?php include("footer.php"); 
?>
	