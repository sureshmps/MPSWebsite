<?php include('header.php');
?>
	<!-- header part ends-->
	
	 <!--====== PAGE BANNER PART START ======-->
    
    <section id="page-banner" class="pt-105 pb-110" data-overlay="8" style="background-color:#2F4F4F">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2>From The Desk Of Principal </h2>
                        
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
   
	
	
	  <section id="blog-page" class="pt-90 pb-120 gray-bg">
        <div class="container">
           <div class="row">
               <div class="col-lg-8">
                   <div class="singel-blog mt-30">
                       <div class="blog-thum">
                          
                       </div>
                       <div class="blog-cont">
                           
                           
                            <p><b>“Education is a shared commitment among dedicated teachers, motivated students and enthusiastic parents with high expectations.”</b><br><br>
							<p>I feel elated in extending a warm welcome to all the youthful and vibrant aspirants into the MPS family.</p><br>
							<p>In <b>MPS</b>, we endeavor to spread education to spread education all around along with extra-curricular activities. It is our earnest effort to make MPS a school with a difference and a school missioned to impart excellence in individuals and prepare world class citizen, professionals, leader, bureaucrats and intellectuals. We lay focus on holistic development of a child where he will be physically strong and mentally healthy.</p><br>
							<p>We at <b>MPS</b> aim at fostering education and unsuting education which would develop our student’s capabilities to enhance & strengthen integrated India and peaceful world.</p><br>
							<p>I welcome parents and students to be part of MPS family as we build through a challenging joyful and enriching educational experience for our young minds.</p><br>
							<p align="right"><b>Rajesh Tiwari</b></p>
							<p align="right"><b>Principal</b></p>
					    </div>
                   </div> <!-- singel blog -->
                   
                        
               </div>
               <div class="col-lg-4">
                   <div class="saidbar">
                       <div class="row">
                           <div class="col-lg-12 col-md-6">
                               <div class="">
                                    <img src="images/trustee/t-2.jpg" alt="About" width="350" height="500">
									<div class="cont">
										<h4>Rajesh Tiwari</h4>
										<h6>Principal</h6>
									</div>
                               </div> <!-- saidbar search -->
                               
                           </div> <!-- categories -->
                           
                           
                       </div> <!-- row -->
                   </div> <!-- saidbar -->
               </div>
           </div> <!-- row -->
        </div> <!-- container -->
    </section>
	
	
<?php include('footer.php');
?>