<?php

	include('header.php');
?>
	 <!--====== PAGE BANNER PART START ======-->
    
    <section id="page-banner" class="pt-105 pb-110 bg_cover" data-overlay="8" style="background-image: url(images/page-banner-3.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2>Our school with:</h2>
                        
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
   
	
	
	  <section id="blog-page" class="pt-90 pb-120 gray-bg">
        <div class="container">
           <div class="row">
               <div class="col-lg-8">
                   <div class="singel-blog mt-30">
                       <div class="blog-thum">
                          
                       </div>
                       <div class="blog-cont">
							<h3>Ours school with:</h3>
                           <ul>
						   
						   <li>Spacious Air-Conditioned classrooms with interactive audio-visual technology.</li>
							<li>Transport facilities enabled with GPS tracking.</li>
							<li>Fully equipped with modern ICT(Information and Communication Technology).</li>
							<li>Well-equipped laboratories for Physics, Chemistry and Biology.</li>
							<li>Best Sports facilities in various disciplines with well experienced coaches.</li>
							<li>Fully-fledged and digitally equipped library.</li>
							<li>Extra-Curricular activities for grooming personality and holistic learning experience.</li>
							<li>High security with CCTV Surveillance and unified technology.</li>
							<li>Well equipped and hygienic Medicare Room.</li>
							<li>Green Lawns.</li>
							<li>Play station for kids.</li>
							<li>Exclusive activity for pre-primary.</li>
							<li>R.O purification plant for drinking water.</li>
							<li>Indoor games room.</li>

						   </ul>
                           
                            
					    </div>
                   </div> <!-- singel blog -->
                   
                        
               </div>
               <div class="col-lg-4">
                   <div class="saidbar">
                       <div class="row">
                           <div class="col-lg-12 col-md-6">
                               <div class="">
                                    <img src="images/teachers/t-1.jpg" alt="About" width="350" height="500">
									<div class="cont">
										<h4></h4>
										<h6></h6>
									</div>
                               </div> <!-- saidbar search -->
                               
                           </div> <!-- categories -->
                           
                           
                       </div> <!-- row -->
                   </div> <!-- saidbar -->
               </div>
           </div> <!-- row -->
        </div> <!-- container -->
    </section>
	
	
<?php

	include('footer.php');
?>